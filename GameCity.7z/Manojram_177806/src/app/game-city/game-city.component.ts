import { Component, OnInit } from '@angular/core';
import { GameService } from '../game.service';

@Component({
  selector: 'app-game-city',
  templateUrl: './game-city.component.html',
  styleUrls: ['./game-city.component.css']
})
export class GameCityComponent implements OnInit {

  constructor(private service:GameService) { }

  ngOnInit() {
  }
play=false;
  setUserDetails(data){
    if(data.userName==""||data.userAddress==""||data.userAmount==undefined){
      alert("Please fill the form")
    }
    else{
    alert("You can start playing now!!!")
    this.service.setUserDetails(data);
    this.play=true;
    }
    
  }
  
  
}
